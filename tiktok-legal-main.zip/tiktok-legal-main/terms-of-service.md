# Conditions d'utilisation

Voici les conditions d'utilisation officielles de SAFTI Connect.

En utilisant notre service, vous acceptez ces termes.
