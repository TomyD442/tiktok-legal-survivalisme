# Mentions légales

Ce site est édité dans le cadre d'une activité d'affiliation TikTok.  
Responsable : [Ton Nom ou Pseudo ici]  
Email : [ton email ici]  
Hébergement : GitHub Pages

---

# Conditions d’utilisation

- Usage autorisé : uniquement pour vos propres comptes TikTok.
- Respect des règles : [Règles de la communauté TikTok](https://www.tiktok.com/community-guidelines).
- Limitation de responsabilité : aucune garantie, service « tel quel ».

---

# Politique de confidentialité

- Données minimales : pas de collecte personnelle hors OAuth TikTok.
- Sécurité : accès TikTok utilisés uniquement pour vos actions.
- Pas de revente ou partage à des tiers.
- Contact pour toute demande ou suppression de données : [ton email ici]
